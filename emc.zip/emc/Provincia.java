public class Provincia {

    private String nombre;

    private Distrito[] distrito;

    private int contador;

    public Provincia(String nombre) {

        this.nombre = nombre;

        this.contador = 0;

        this.distrito = new Distrito[3];
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDistrito(Distrito distrito) {

        this.distrito[this.contador] = distrito;

        this.contador++;
    }

    public Distrito[] getDistrito() {
        return distrito;
    }
}
