public class Main {

    public static void main(String args[])
    {
        Distrito ambo = new Distrito("AMBO");
        Distrito cayna = new Distrito("CAYNA");
        Distrito colpas = new Distrito("COLPAS");

        Distrito laUnion = new Distrito("LA UNION");
        Distrito chuquis = new Distrito("CHUQUIS");
        Distrito marias = new Distrito("MARIAS");


        Provincia provinciaAmbo = new Provincia("AMBO");
        provinciaAmbo.setDistrito(ambo);
        provinciaAmbo.setDistrito(cayna);
        provinciaAmbo.setDistrito(colpas);

        Provincia provinciaDosDeMayo = new Provincia("DOS DE MAYO");
        provinciaDosDeMayo.setDistrito(laUnion);
        provinciaDosDeMayo.setDistrito(chuquis);
        provinciaDosDeMayo.setDistrito(marias);

        Departamento departamento = new Departamento("HUANUCO");
        System.out.println("Departamento: "+departamento.getNombre());
        departamento.setProvincia(provinciaAmbo);
        departamento.setProvincia(provinciaDosDeMayo);

        for(Provincia p: departamento.getProvincia())
        {
            System.out.println("Provincia: "+p.getNombre());

            for(Distrito d: p.getDistrito())
            {
                System.out.println("Distrito: "+d.getNombre());
            }
        }


        Distrito chavin = new Distrito("CHAVIN");
        Provincia chincha = new Provincia("DOS DE MAYO");
        chincha.setDistrito(chavin);
        Departamento ica = new Departamento("ICA");
        System.out.println("Departamento: "+ica.getNombre());
        ica.setProvincia(chincha);

    }
}
