public class Departamento {

    private String nombre;

    private Provincia[] provincia;

    private int contador;

    public Departamento(String nombre) {

        this.nombre = nombre;

        this.contador = 0;

        this.provincia = new Provincia[2];
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setProvincia(Provincia provincia) {

        this.provincia[this.contador++] = provincia;
    }

    public Provincia[] getProvincia() {
        return provincia;
    }
}
